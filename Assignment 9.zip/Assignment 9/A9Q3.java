class Person{
String firstname;
String lastname;
Person(String firstname,String lastname){
this.firstname =firstname;
this.lastname =lastname;
}
String getFirstname(){
return firstname;
}
String getLastName(){
return lastname;
}
}
class Employee extends Person{
String employeeid;
String employeejobtitle;
Employee(String firstname,String lastname,String employee,String employeejobtitle){
super(firstname,lastname);
this.employeeid=employeeid;
this.employeejobtitle=employeejobtitle;
}
String getEmployeeId(){
return employeeid;
}
String getLastName(){
return super.getLastName()+ "(" + employeejobtitle+ ")";
}
}
class A9Q3{
public static void main(String args[]){
Employee e= new Employee("Shivam","kumar","Emp80","Dataanalyst");
System.out.println("FirstName : " + e.getFirstname());
System.out.println("LastName :" +e.getLastName());
System.out.println("EmployeeId:" +e.getEmployeeId());
}
}



