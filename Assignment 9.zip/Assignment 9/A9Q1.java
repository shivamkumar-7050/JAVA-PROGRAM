class Vehicle{
 void drive(){
System.out.println("");
}
}
class Car extends Vehicle{
void drive(){
System.out.println("Reparing a car");
}
public class A9Q1{
public static void main(String args[]){
Vehicle v=new Car();
v.drive();
}
}

