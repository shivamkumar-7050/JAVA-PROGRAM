import java.util.Scanner;
class A3Q2{
public static void main(String SCP[]){
Scanner sc= new Scanner(System.in);
System.out.println("Enter basi salary:");
double basic= sc.nextDouble();
sc.close();
double HRA= basic*0.1;
double DA= basic*0.6;
double GS= basic + DA +HRA;
System.out.println("Gross salary calculated: Rs" +GS);
}
}