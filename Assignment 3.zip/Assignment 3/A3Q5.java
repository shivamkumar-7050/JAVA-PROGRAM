import java.util.Scanner;
class A3Q5{
public static void main(String SCP[]){
Scanner sc= new Scanner(System.in);
double costp, sellp, diff, loss, profit;
System.out.print("Enter cost price:");
costp= sc.nextDouble();
System.out.print("Enter sell price:");
sellp= sc.nextDouble();
if(costp== sellp){
System.out.print("no profit or loss");
}
else if (costp>sellp){
diff= sellp-costp;
loss=(diff*100)/costp;
System.out.print("Loss percentage:" + loss + "%");
}
else{
diff=sellp-costp;
profit=(diff*100)/costp;
System.out.print("profit percentage:" + profit);
}
sc.close();
}
}