import java.util.Scanner;
class A3Q4{
public static void main(String args[]){
Scanner sc= new Scanner(System.in);
System.out.println("Enter any number:");
double num=sc.nextDouble();
if(num>0.00){
System.out.print("Positive number");
}
else if(num<0.00){
System.out.print("Negative number");
}else{
System.out.print("Zero");
}
sc.close();
}
}