class Rectangle{
int width;
int height;
void area(int w, int h){
width=w;
height=h;
int a= width*height;
System.out.println("Area of Rectangle:" +width);
}
void perimeter(int w, int h){
width=w;
height=h;
int p=2*(width+height);
System.out.print("Perimeter of Rectangle:" +p);
}
public static void main(String args[]){
Rectangle r= new Rectangle();
r.area(5,6);
r.perimeter(4,10);
}
}